  <!-- Jquery -->
  <script src="{{ asset('assets/frontassets/js/jquery.min.js')}}"></script>
  <script src="{{ asset('assets/frontassets/js/jquery-migrate-3.0.0.js')}}"></script>
  <script src="{{ asset('assets/frontassets/js/jquery-ui.min.js')}}"></script>
  <!-- Popper JS -->
  <script src="{{ asset('assets/frontassets/js/popper.min.js')}}"></script>
  <!-- Bootstrap JS -->
  <script src="{{ asset('assets/frontassets/js/bootstrap.min.js')}}"></script>
  <!-- Color JS -->
  <script src="{{ asset('assets/frontassets/js/colors.js')}}"></script>
  <!-- Slicknav JS -->
  <script src="{{ asset('assets/frontassets/js/slicknav.min.js')}}"></script>
  <!-- Owl Carousel JS -->
  <!--<script src="{{ asset('assets/frontassets/js/owl-carousel.js')}}"></script>-->
  <!-- Magnific Popup JS -->
  <script src="{{ asset('assets/frontassets/js/magnific-popup.js')}}"></script>
  <!-- Waypoints JS -->
  <script src="{{ asset('assets/frontassets/js/waypoints.min.js')}}"></script>
  <!-- Countdown JS -->
  <script src="{{ asset('assets/frontassets/js/finalcountdown.min.js')}}"></script>
  <!-- Nice Select JS -->
  <!--<script src="{{ asset('assets/frontassets/js/nicesellect.js')}}"></script>-->
  <!-- Flex Slider JS -->
  <script src="{{ asset('assets/frontassets/js/flex-slider.js')}}"></script>
  <!-- ScrollUp JS -->
  <script src="{{ asset('assets/frontassets/js/scrollup.js')}}"></script>
  <!-- Onepage Nav JS -->
  <script src="{{ asset('assets/frontassets/js/onepage-nav.min.js')}}"></script>
  <!-- Easing JS -->
  <script src="{{ asset('assets/frontassets/js/easing.js')}}"></script>
  <!-- Active JS -->
  <script src="{{ asset('assets/frontassets/js/active.js')}}"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js" integrity="sha512-qFOQ9YFAeGj1gDOuUD61g3D+tLDv3u1ECYWqT82WQoaWrOhAY+5mRMTTVsQdWutbA5FORCnkEPEgU0OF8IzGvA==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
  <script src="https://cdn.jsdelivr.net/npm/bs5-lightbox@1.8.3/dist/index.bundle.min.js"></script>
</body>

</html>