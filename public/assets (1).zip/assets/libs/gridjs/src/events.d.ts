import { TableEvents } from './view/table/events';
import { ContainerEvents } from './view/events';
export declare type GridEvents = ContainerEvents & TableEvents;
